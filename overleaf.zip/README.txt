Overleaf package: Scope-Aware Security Triage

Upload this ZIP to Overleaf and select draft.tex as the main document.
Use pdfLaTeX with BibTeX. The acmart class is provided by Overleaf.
The manuscript uses refs.bib; references.bib is an identical compatibility
copy and is not read separately. Keep the figures/ directory beside draft.tex.
Code, observed results, and reproduction instructions:
https://github.com/Saurav-K-Aryal/scopeledger-pilot
